#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int main(int argc, char** argv)
{
	string line_1="", line_2="";
	for (int i=0; i<10; i++) {
		if (i%2==0)
			line_2 += to_string(i) + " ";
		else 
			line_1 += to_string(i) + " ";
	}
	if (argc > 2) {
		ifstream fin(argv[1]);
		fin.close();
		ofstream fout(argv[2]);
		fout << line_1;
		fout.close();

	}
	exit(1);
}