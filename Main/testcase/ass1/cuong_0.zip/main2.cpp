#include <iostream>
using namespace std;

int main()
{
	cout << "s1212";
	exit(1);
}