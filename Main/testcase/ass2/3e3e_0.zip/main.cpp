#include <fstream>
int main(int argc, char** argv)
{
	std::ofstream fout(argv[2]);
	fout << "1 3 5 7 9";
	fout.close();
	return 0;
}