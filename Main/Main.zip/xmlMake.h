#ifndef _xmlMake_H_
#define _xmlMake_H_
#include <string>
void createMakeFile(const std::string& dir);
void createBuildXml(const std::string& dir);
#endif