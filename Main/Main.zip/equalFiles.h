#ifndef EQUAL_FILES
#define EQUAL_FILES

bool equalFiles(std::ifstream& in1, std::ifstream& in2);

#endif // !EQUAL_FILES

