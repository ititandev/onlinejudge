#ifndef _MY_TIME_H
#define _MY_TIME_H
#include <string>
unsigned long getTimeStamp(const std::string& path);
#endif
